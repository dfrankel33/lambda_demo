# s3-lambda-inception
A lambda function, which can be used to download a lambda deployment package from a URL and upload it to S3
